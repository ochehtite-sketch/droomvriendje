console.log('Droomvriendjes assets loaded');
